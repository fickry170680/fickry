# SpamCall
Spam Call Unlimited
<li>$ pkg update && pkg upgrade
<li>$ pkg install php
<li>$ pkg install git
<li>$ git clone https://github.com/Aditya021/SpamCall
<li>$ cd SpamSms
<li>$ php SpamCall.php
<li> Masukan No Target ===> 
<li> Mode Banyak (y/n) ===> UNTUK Spam Lebih Dari 1
<li> JumlahSpam ===> Masukan Jumlah yang ingin dispam
<li> [Succes]
